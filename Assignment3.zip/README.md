# Assignment3
You will run the notebooks Naive_Bayes_Classifier.ipynb and Logistic_Regression.ipynb in jupyter notebook, or view the results we have already found.